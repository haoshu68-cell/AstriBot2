import importlib.util,json,sys,time
from pathlib import Path
p=Path('/home/yjh/WorkSpace/astribot_sdk_ros2/ws_robot/src/astribot_s1_perception_native/test/test_map_odom_ros.py')
spec=importlib.util.spec_from_file_location('fixture',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=Path('/tmp/codex_map_odom_20260921/shutdown_probe');base.mkdir(exist_ok=True)
results=[]
for paced in [False,True]:
 for iteration in range(8):
  impl='python' if iteration%2==0 else 'cpp'
  d=base/f'{"paced" if paced else "original"}_{iteration}_{impl}';d.mkdir(exist_ok=True)
  r=m.Runtime(impl,d,{'use_sim_time':False,'tf_timeout_sec':.2,'report_period_sec':.1})
  sent=0;start=time.monotonic();body_error=None;close_error=None
  try:
   r.until(lambda:'第 1 次' in r.log_path.read_text(),timeout=2.)
   first=time.monotonic();r.until(lambda:'第 2 次' in r.log_path.read_text(),timeout=2.)
   timeout_gap=time.monotonic()-first
   until=time.monotonic()+1.5;pub_start=time.monotonic()
   while not r.samples and time.monotonic()<until:
    now=time.time();r.tf_pub.publish(m.TFMessage(transforms=[m.edge('map','aft_mapped',now,x=2.),m.edge('odom','astribot_torso_base',now,x=.5)]));sent+=1
    if paced:
     wait=time.monotonic()+.01
     while time.monotonic()<wait:r.executor.spin_once(timeout_sec=.002)
    else:r.executor.spin_once(timeout_sec=.01)
   assert r.samples and abs(r.samples[-1]['xyz'][0]-1.5)<1e-9
   pub_seconds=time.monotonic()-pub_start
  except Exception as e:body_error=repr(e)
  finally:
   try:r.close()
   except Exception as e:close_error=repr(e)
  result=dict(impl=impl,paced=paced,iteration=iteration,sent=sent,pub_seconds=pub_seconds,timeout_gap=timeout_gap,samples=len(r.samples),exit=r.proc.returncode,body_error=body_error,close_error=close_error)
  results.append(result);print(json.dumps(result),flush=True)
(base/'results.json').write_text(json.dumps(results,indent=2))
