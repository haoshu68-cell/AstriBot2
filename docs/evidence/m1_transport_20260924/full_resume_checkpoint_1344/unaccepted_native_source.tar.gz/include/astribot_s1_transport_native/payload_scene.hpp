#pragma once
#include <astribot_s1_payload_state/ledger.hpp>
#include <moveit_msgs/msg/planning_scene.hpp>
namespace astribot::transport {
// A previous, still-valid ledger revision may lag the physical/scene readback.
// It authorizes no progress; source changes or a newer unexpected revision fail.
void require_payload_observation_bound(const astribot::payload::Observation &expected,
 const astribot::payload::Observation &latest);
bool payload_revision_ready(const astribot::payload::State &state,
 const astribot::payload::Observation &expected,const std::string &ledger_epoch);
moveit_msgs::msg::PlanningScene payload_scene_diff(const moveit_msgs::msg::PlanningScene &before,
 const astribot::payload::Observation &physical,const std::string &object,bool attach,
 const geometry_msgs::msg::Pose &base_object,const std::string &base,const std::set<std::string> &known_links);
void validate_payload_scene(const moveit_msgs::msg::PlanningScene &before,
 const moveit_msgs::msg::PlanningScene &after,const astribot::payload::Observation &physical,
 const std::string &object,bool attach,const geometry_msgs::msg::Pose &base_object,const std::string &base,const std::set<std::string> &known_links);
}
