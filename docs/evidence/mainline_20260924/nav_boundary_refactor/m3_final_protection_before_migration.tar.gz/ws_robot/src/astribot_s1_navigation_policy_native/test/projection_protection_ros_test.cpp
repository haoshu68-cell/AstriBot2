#include <gtest/gtest.h>
#include <astribot_perception_msgs/msg/camera_health.hpp>
#include <astribot_perception_msgs/msg/projection_health.hpp>
#define main protection_program_main
#include "../src/final_protection_node.cpp"
#undef main
#include <thread>
using namespace std::chrono_literals;
class ProjectionProtectionRos:public ::testing::Test {
 protected:
  static void SetUpTestSuite(){rclcpp::init(0,nullptr);}
  static void TearDownTestSuite(){rclcpp::shutdown();}
  void SetUp()override {
    rclcpp::NodeOptions options;options.parameter_overrides({rclcpp::Parameter("use_sim_time",true),
      rclcpp::Parameter("required_projection_cameras","[\"head_rgbd\"]")});
    node=std::make_shared<astribot::navigation::FinalProtectionNode>(options);
    probe=std::make_shared<rclcpp::Node>("projection_protection_probe",options);
    profile=astribot::navigation::load_policy_profile(node->get_parameter("profile").as_string(),true);
    raw=probe->create_publisher<astribot_perception_msgs::msg::CameraHealth>("/perception/camera_health/head_rgbd",rclcpp::QoS(1).transient_local());
    processing=probe->create_publisher<astribot_perception_msgs::msg::ProjectionHealth>("/perception/projection_health/head_rgbd",rclcpp::QoS(1).transient_local());
    commands=probe->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel_policy_input",10);
    proposals=probe->create_publisher<astribot_navigation_msgs::msg::MotionConstraint>("/navigation_policy/proposed_constraint",10);
    scans=probe->create_publisher<sensor_msgs::msg::LaserScan>("/scan_from_cloud",rclcpp::SensorDataQoS());
    odometry=probe->create_publisher<nav_msgs::msg::Odometry>("/odom",rclcpp::SensorDataQoS());
    envelopes=probe->create_publisher<astribot_navigation_msgs::msg::RobotEnvelope>("/navigation/robot_envelope",10);
    output=probe->create_subscription<geometry_msgs::msg::Twist>("/cmd_vel",10,[this](geometry_msgs::msg::Twist::ConstSharedPtr m){last_speed=m->linear.x;});
    diagnostics=probe->create_subscription<std_msgs::msg::String>("/navigation_policy/protection_state",10,[this](std_msgs::msg::String::ConstSharedPtr m){diagnostic=nlohmann::json::parse(m->data);});
    started=std::chrono::steady_clock::now();exec.add_node(node);exec.add_node(probe);pump(.15);
  }
  void pump(double seconds) {
    const auto end=std::chrono::steady_clock::now()+std::chrono::duration<double>(seconds);
    while(std::chrono::steady_clock::now()<end) {
      const auto t=10000000000LL+std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-started).count();
      for(auto n:{std::static_pointer_cast<rclcpp::Node>(node),probe}) {
        auto* c=n->get_clock()->get_clock_handle();ASSERT_EQ(rcl_enable_ros_time_override(c),RCL_RET_OK);ASSERT_EQ(rcl_set_ros_time_override(c,t),RCL_RET_OK);
      }
      const rclcpp::Time now(t);astribot_perception_msgs::msg::CameraHealth h;
      h.camera_id="head_rgbd";h.header.frame_id=h.frame_id="head_optical";h.header.stamp=h.capture_stamp=now;
      h.valid_until=now+rclcpp::Duration::from_seconds(.25);h.source_epoch="raw1";h.valid=true;h.calibration_revision=1;raw->publish(h);
      if(publish_projection) {
        astribot_perception_msgs::msg::ProjectionHealth p;p.header=h.header;p.camera_id=h.camera_id;
        p.processing_epoch=processing_epoch;p.capture_stamp=h.capture_stamp;p.valid_until=h.valid_until;
        p.valid=processing_valid;p.sequence=++health_sequence;processing->publish(p);
      }
      nav_msgs::msg::Odometry o;o.header.stamp=now;odometry->publish(o);
      sensor_msgs::msg::LaserScan scan;scan.header.frame_id=profile.at("base_frame");scan.header.stamp=now;
      scan.range_min=.1;scan.range_max=10.;scan.angle_min=-3.14159265359;scan.angle_increment=2*3.14159265359/720;
      scan.ranges.assign(721,std::numeric_limits<float>::infinity());
      if(obstacle)scan.ranges[360]=.3f;
      scans->publish(scan);
      astribot_navigation_msgs::msg::RobotEnvelope e;e.stamp=now;e.frame_id=profile.at("base_frame");e.epoch=1;
      e.posture_id="fixture";e.transport_ready=true;e.lease_s=.3;
      e.half_length_m=profile.at("half_length_m");e.half_width_m=profile.at("half_width_m");e.height_m=profile.at("height_m");
      e.payload_mass_kg=profile.at("payload_mass_kg");e.max_speed_m_s=profile.at("max_speed_m_s");
      e.max_angular_speed_rad_s=profile.at("max_angular_speed_rad_s");e.max_acceleration_m_s2=profile.at("max_acceleration_m_s2");
      e.brake_deceleration_m_s2=profile.at("brake_deceleration_m_s2");envelopes->publish(e);
      if(publish_proposal) {
        astribot_navigation_msgs::msg::MotionConstraint p;p.stamp=now;p.epoch=1;p.sequence=++proposal_sequence;
        p.lease_s=.3;p.max_linear_speed=.2;p.max_angular_speed=.5;p.reason="FIXTURE_CLEAR";proposals->publish(p);
      }
      if(publish_command){geometry_msgs::msg::Twist c;c.linear.x=.1;commands->publish(c);}
      exec.spin_some();std::this_thread::sleep_for(10ms);
    }
  }
  void TearDown()override{exec.remove_node(node);exec.remove_node(probe);node.reset();probe.reset();}
  bool publish_projection=false,processing_valid=true,publish_proposal=true,publish_command=true,obstacle=false;
  std::string processing_epoch="processing1";double last_speed=-1.;uint64_t health_sequence=0,proposal_sequence=0;
  nlohmann::json profile,diagnostic;std::chrono::steady_clock::time_point started;
  std::shared_ptr<astribot::navigation::FinalProtectionNode> node;rclcpp::Node::SharedPtr probe;
  rclcpp::executors::SingleThreadedExecutor exec;
  rclcpp::Publisher<astribot_perception_msgs::msg::CameraHealth>::SharedPtr raw;
  rclcpp::Publisher<astribot_perception_msgs::msg::ProjectionHealth>::SharedPtr processing;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr commands;
  rclcpp::Publisher<astribot_navigation_msgs::msg::MotionConstraint>::SharedPtr proposals;
  rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scans;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odometry;
  rclcpp::Publisher<astribot_navigation_msgs::msg::RobotEnvelope>::SharedPtr envelopes;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr output;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr diagnostics;
};
TEST_F(ProjectionProtectionRos, ProcessingFaultStopsAndRequiresFreshCommandsAfterRecovery) {
  pump(.8);EXPECT_DOUBLE_EQ(last_speed,0.);
  publish_projection=true;pump(1.);ASSERT_GT(last_speed,.01);
  processing_valid=false;pump(.15);EXPECT_DOUBLE_EQ(last_speed,0.);
  publish_command=false;publish_proposal=false;processing_valid=true;processing_epoch="processing2";
  pump(.8);EXPECT_DOUBLE_EQ(last_speed,0.);
  publish_proposal=true;publish_command=true;pump(1.);EXPECT_GT(last_speed,.01);
  ASSERT_TRUE(diagnostic.contains("projection_ready"));EXPECT_TRUE(diagnostic.at("projection_ready").get<bool>());
}

TEST_F(ProjectionProtectionRos, ProposalGapStopsButDoesNotEraseContinuousClearance) {
  publish_projection=true;pump(1.1);ASSERT_GT(last_speed,.01);
  publish_proposal=false;pump(.4);ASSERT_DOUBLE_EQ(last_speed,0.);
  ASSERT_EQ(diagnostic.at("reason"),"POLICY_UNAVAILABLE");
  publish_proposal=true;pump(.2);
  EXPECT_GT(last_speed,.01) << "Fresh proposal must not restart a completed independent clearance interval";
}

TEST_F(ProjectionProtectionRos, RealObstacleDuringProposalGapRestartsClearance) {
  publish_projection=true;pump(1.1);ASSERT_GT(last_speed,.01);
  publish_proposal=false;obstacle=true;pump(.4);ASSERT_DOUBLE_EQ(last_speed,0.);
  ASSERT_EQ(diagnostic.at("reason"),"INDEPENDENT_SWEEP_RISK");
  publish_proposal=true;obstacle=false;pump(.2);
  EXPECT_DOUBLE_EQ(last_speed,0.);
  EXPECT_EQ(diagnostic.at("reason"),"PROTECTION_CLEAR_CONFIRMATION");
  pump(.6);EXPECT_GT(last_speed,.01);
}
