#include "astribot_navigation_zones/client.hpp"
#include "astribot_s1_navigation_policy_native/final_protection_core.hpp"
#include "astribot_s1_navigation_policy_native/navigation_math.hpp"
#include "astribot_s1_navigation_policy_native/policy_profile.hpp"
#include "astribot_s1_navigation_policy_native/projection_capability.hpp"
#include "astribot_s1_navigation_policy_native/publication_lease.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <limits>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <std_msgs/msg/string.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <astribot_navigation_msgs/msg/motion_constraint.hpp>
#include <astribot_navigation_msgs/msg/envelope_apply_status.hpp>
#include <astribot_perception_msgs/msg/camera_health.hpp>
#include <astribot_perception_msgs/msg/projection_health.hpp>

namespace astribot::navigation {
namespace {
using Constraint = astribot_navigation_msgs::msg::MotionConstraint;
using Scan = sensor_msgs::msg::LaserScan;
using Odom = nav_msgs::msg::Odometry;
using Twist = geometry_msgs::msg::Twist;
using ApplyStatus = astribot_navigation_msgs::msg::EnvelopeApplyStatus;
constexpr double absent = -std::numeric_limits<double>::infinity();
double steady_seconds() {
  return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
std::uint64_t steady_ns() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::steady_clock::now().time_since_epoch()).count();
}
double seconds(const builtin_interfaces::msg::Time& time) {
  return time.sec + time.nanosec * 1e-9;
}
int64_t valid_ns(const builtin_interfaces::msg::Time& t) {
  return t.sec<0||t.nanosec>=1000000000u?0:int64_t(t.sec)*1000000000LL+t.nanosec;
}
std::vector<double> velocity(const Twist& message) {
  return {message.linear.x, message.linear.y, message.angular.z};
}
nlohmann::json age(double value) {
  return std::isfinite(value) ? nlohmann::json(value) : nlohmann::json(nullptr);
}
}  // namespace

class FinalProtectionNode final : public rclcpp::Node {
public:
  explicit FinalProtectionNode(const rclcpp::NodeOptions& options=rclcpp::NodeOptions()) : Node("navigation_final_protection",options) {
    const char* timing_diagnostics = std::getenv("ASTRIBOT_SCAN_TIMING_DIAGNOSTICS");
    timing_diagnostics_ = timing_diagnostics && std::string(timing_diagnostics) == "1";
    const auto profile_path = declare_parameter<std::string>("profile",
      ament_index_cpp::get_package_share_directory("astribot_s1_navigation_policy") + "/config/simulation.json");
    const auto scan_topic = declare_parameter<std::string>("scan_topic", "/scan_from_cloud");
    const auto mode = declare_parameter<std::string>("navigation_geometry_mode", "legacy");
    if (mode != "legacy" && mode != "fixed_v2") throw std::invalid_argument("invalid navigation_geometry_mode");
    profile_ = std::make_unique<ProtectionProfile>(load_policy_profile(profile_path,
      get_parameter("use_sim_time").as_bool()), mode == "fixed_v2");
    clock_ = std::make_unique<ControlTime>(profile_->simulated(), profile_->value("command_timeout_s"));
    clock_->advance(now().seconds(), steady_seconds());
    tf_ = std::make_unique<tf2_ros::Buffer>(get_clock());
    listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_, this, true);
    require_zones_=declare_parameter("require_navigation_zones",false);if(require_zones_){zones_.init(*this);zone_ack_=create_publisher<std_msgs::msg::String>("/navigation_zones/applied",10);}
    output_ = create_publisher<Twist>("/cmd_vel", 10);
    constraint_ = create_publisher<Constraint>("/navigation_policy/constraint", 10);
    diagnostics_ = create_publisher<std_msgs::msg::String>("/navigation_policy/protection_state", 10);
    rcl_interfaces::msg::ParameterDescriptor camera_descriptor;camera_descriptor.read_only=true;
    const auto required_cameras=nlohmann::json::parse(declare_parameter<std::string>("required_projection_cameras","[]",camera_descriptor)).get<std::vector<std::string>>();
    camera_gate_=std::make_unique<ProjectionCapabilityGate>(required_cameras);
    for(const auto& camera:required_cameras) {
      using Raw=astribot_perception_msgs::msg::CameraHealth;
      using Processing=astribot_perception_msgs::msg::ProjectionHealth;
      camera_subscriptions_.push_back(create_subscription<Raw>("/perception/camera_health/"+camera,rclcpp::QoS(4).reliable().transient_local(),
        [this,camera](Raw::ConstSharedPtr h) {
          if(h->camera_id!=camera)return;
          camera_gate_->raw({h->camera_id,h->frame_id,h->source_epoch,h->valid&&h->header.frame_id==h->frame_id,
            valid_ns(h->header.stamp),valid_ns(h->capture_stamp),valid_ns(h->valid_until)},now().nanoseconds(),steady_seconds());
        }));
      camera_subscriptions_.push_back(create_subscription<Processing>("/perception/projection_health/"+camera,rclcpp::QoS(4).reliable().transient_local(),
        [this,camera](Processing::ConstSharedPtr h) {
          if(h->camera_id!=camera)return;
          camera_gate_->processing({h->camera_id,h->header.frame_id,h->processing_epoch,h->valid,
            valid_ns(h->header.stamp),valid_ns(h->capture_stamp),valid_ns(h->valid_until)},now().nanoseconds(),steady_seconds());
        }));
    }
    if (mode == "legacy") {
      envelope_ = create_subscription<ProtectionEnvelope>("/navigation/robot_envelope", 10,
        [this](ProtectionEnvelope::ConstSharedPtr message) {
          try { profile_->accept(*message, now().nanoseconds(), epoch_); }
          catch (const std::invalid_argument& error) { RCLCPP_WARN(get_logger(), "%s", error.what()); }
        });
    } else {
      ack_ = create_publisher<ApplyStatus>("/navigation/envelope_applied", 10);
      v2_ = create_subscription<ProtectionEnvelopeV2>("/navigation/envelope_v2", 10,
        [this](ProtectionEnvelopeV2::ConstSharedPtr message) {
          try {
            if (profile_->accept(*message, now().nanoseconds(), epoch_)) {
              ApplyStatus ack;
              ack.header.stamp = now(); ack.header.frame_id = profile_->base_frame();
              ack.coordinator_session_id = message->coordinator_session_id;
              ack.consumer_id = "protection"; ack.envelope_epoch = message->epoch;
              ack.installed_geometry_hash = message->installed_geometry_hash;
              ack.applied = true; ack.reason = "POLYGON_APPLIED"; ack_->publish(ack);
            }
          } catch (const std::invalid_argument& error) { RCLCPP_WARN(get_logger(), "%s", error.what()); }
        });
    }
    input_ = create_subscription<Twist>("/cmd_vel_policy_input", 10,
      [this](Twist::ConstSharedPtr message) {
        command_ = velocity(*message); command_at_ = steady_seconds(); command_ros_at_ = now().seconds();
        tick();
      });
    odom_ = create_subscription<Odom>("/odom", rclcpp::SensorDataQoS(),
      [this](Odom::ConstSharedPtr message) {
        if (message->header.stamp.sec < 0 || message->header.stamp.nanosec >= 1000000000u) return;
        const double capture = seconds(message->header.stamp);
        if (!clock_->accepts(capture)) return;
        measured_ = velocity(message->twist.twist); odom_at_ = steady_seconds(); odom_stamp_ = capture;
        odom_stamp_ns_ = valid_ns(message->header.stamp);
      });
    scan_ = create_subscription<Scan>(scan_topic, rclcpp::SensorDataQoS(),
      [this](Scan::ConstSharedPtr message) {
        ++scan_received_;
        if (message->header.stamp.sec < 0 || message->header.stamp.nanosec >= 1000000000u) {
          ++scan_invalid_; return;
        }
        const std::vector<double> ranges(message->ranges.begin(), message->ranges.end());
        if (!scan_usable(ranges, message->range_min, message->range_max, message->angle_min,
            message->angle_increment, profile_->value("scan_min_valid_fraction"))) {
          ++scan_invalid_; return;
        }
        pending_.push_back(message);
        if (pending_.size() > 5) pending_.erase(pending_.begin());
        process_scans(now().seconds());
      });
    proposal_sub_ = create_subscription<Constraint>("/navigation_policy/proposed_constraint", 10,
      [this](Constraint::ConstSharedPtr message) {
        if (!clock_->accepts(seconds(message->stamp))) return;
        if (proposal_ && message->epoch == proposal_->epoch && message->sequence <= proposal_->sequence) return;
        if (!std::isfinite(message->lease_s) || !std::isfinite(message->max_linear_speed) ||
            !std::isfinite(message->max_angular_speed) || message->lease_s <= 0. || message->lease_s > .5 ||
            message->max_linear_speed < 0. || message->max_angular_speed < 0.) return;
        proposal_ = message; proposal_at_ = steady_seconds();
      });
    // This must remain a steady timer: ROS timers cannot stop stale commands
    // while simulated time is frozen. All callbacks have one serialized writer.
    timer_ = create_wall_timer(std::chrono::milliseconds(20), [this] { tick(); });
  }

  void stop() { if (rclcpp::ok()) output_->publish(Twist()); }

private:
  void process_scans(double ros) {
    std::vector<Scan::ConstSharedPtr> pending;
    for (const auto& message : pending_) {
      const double capture = seconds(message->header.stamp);
      if (!clock_->accepts(capture) || capture <= scan_stamp_) continue;
      if (ros - capture > profile_->value("sensor_timeout_s")) { ++scan_expired_; continue; }
      if (capture > ros) { pending.push_back(message); continue; }
      try {
        const auto transform = tf_->lookupTransform(profile_->base_frame(), message->header.frame_id,
          rclcpp::Time(message->header.stamp));
        const auto& q = transform.transform.rotation;
        const auto& t = transform.transform.translation;
        std::vector<std::array<double, 2>> points;
        for (std::size_t i = 0; i < message->ranges.size(); ++i) {
          const double range = message->ranges[i];
          if (!std::isfinite(range) || range < message->range_min || range >= message->range_max) continue;
          const double a = message->angle_min + i * static_cast<double>(message->angle_increment);
          const double x = range * std::cos(a), y = range * std::sin(a);
          // Same quaternion rotation as observer.rotate, including full roll/pitch.
          const double tx = -2. * q.z * y, ty = 2. * q.z * x, tz = 2. * (q.x * y - q.y * x);
          points.push_back({x + q.w * tx + q.y * tz - q.z * ty + t.x,
                            y + q.w * ty + q.z * tx - q.x * tz + t.y});
        }
        const double yaw = std::atan2(2. * (q.w * q.z + q.x * q.y), 1. - 2. * (q.y * q.y + q.z * q.z));
        const auto cones = scan_coverage(std::vector<double>(message->ranges.begin(), message->ranges.end()),
          message->range_min, message->range_max, message->angle_min, message->angle_increment, yaw);
        // scan_coverage returns XYZ + half-angle; motion admission consumes XY
        // + half-angle, matching sensor_health.py's BearingCone adapter.
        coverage_.clear();
        for (std::size_t i = 0; i < cones.size(); i += 4) {
          coverage_.insert(coverage_.end(), {cones[i], cones[i + 1], cones[i + 3]});
        }
        points_ = std::move(points); scan_at_ = steady_seconds(); scan_stamp_ = capture;
        scan_stamp_ns_ = valid_ns(message->header.stamp);
        ++scan_transformed_; last_scan_error_.clear();
      } catch (const std::exception& error) {
        ++scan_tf_waits_; last_scan_error_ = error.what(); pending.push_back(message);
      }
    }
    pending_.clear();
    for (const auto& message : pending) if (seconds(message->header.stamp) > scan_stamp_) pending_.push_back(message);
  }

  void tick() {
    const double wall = steady_seconds(); const auto ros = now(); const double seconds_now = ros.seconds();
    const auto timing = clock_->advance(seconds_now, wall);
    if (timing.reset) {
      ++epoch_; proposal_.reset(); scan_at_ = odom_at_ = scan_stamp_ = odom_stamp_ = absent;
      scan_stamp_ns_ = odom_stamp_ns_ = -1;
      pending_.clear(); command_ = {0., 0., 0.}; command_at_ = command_ros_at_ = absent; clear_at_.reset();
    } else if (timing.stop_commands) {
      proposal_.reset(); command_ = {0., 0., 0.}; command_at_ = command_ros_at_ = absent; clear_at_.reset();
    }
    const auto decision_epoch = epoch_;
    process_scans(seconds_now);
    const auto camera_status=camera_gate_->evaluate(ros.nanoseconds(),wall);
    if(camera_gate_->enabled()&&camera_status.revision!=camera_revision_) {
      // Latched faults and completed recovery each revoke cached control input.
      // Twist retains the existing receipt-time freshness contract.
      camera_revision_=camera_status.revision;proposal_.reset();command_={0.,0.,0.};
      command_at_=command_ros_at_=absent;clear_at_.reset();
    }
    const auto& p = *profile_;
    const bool fresh = clock_->fresh(scan_stamp_, scan_at_, p.value("sensor_timeout_s"), seconds_now, wall) &&
      clock_->fresh(odom_stamp_, odom_at_, p.value("sensor_timeout_s"), seconds_now, wall);
    const bool lease = proposal_ && (!camera_gate_->enabled()||valid_ns(proposal_->stamp)>camera_status.released_ns) &&
      clock_->fresh(seconds(proposal_->stamp), proposal_at_, proposal_->lease_s, seconds_now, wall);
    std::string reason = !fresh ? "INPUT_UNAVAILABLE" : (!lease ? "POLICY_UNAVAILABLE" : proposal_->reason);
    // Clearance is evidence from the independent sensors, not the lifetime of
    // a policy message. A proposal gap stops motion without erasing continuous
    // clear observations; actual environment/input faults still restart it.
    bool independent_stop = !fresh;
    if (!p.ready(ros.nanoseconds(), epoch_)) { independent_stop = true; reason = "ROBOT_ENVELOPE_UNAVAILABLE"; }
    if (fresh && (!coverage_allows_motion(coverage_, command_[0], command_[1], command_[2]) ||
                  !coverage_allows_motion(coverage_, measured_[0], measured_[1], measured_[2]))) {
      independent_stop = true; reason = "INDEPENDENT_COVERAGE_UNAVAILABLE";
    }
    if (fresh && (protection_swept_collision(points_, command_, p) || protection_swept_collision(points_, measured_, p))) {
      independent_stop = true; reason = "INDEPENDENT_SWEEP_RISK";
    }
    if(require_zones_){
      auto snapshot=zones_.constraints.get();bool installed=bool(snapshot);std::string zone_reason="ZONES_UNAVAILABLE";
      if(snapshot)try{
        auto transform=tf_->lookupTransform("map",p.base_frame(),tf2::TimePointZero);
        double age=seconds_now-rclcpp::Time(transform.header.stamp).seconds();
        if(age>.5||age<-.1)throw std::runtime_error("ZONES_TF_STALE");
        const auto&q=transform.transform.rotation;double yaw=std::atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));
        double radius=std::hypot(p.value("half_length_m"),p.value("half_width_m"));
        for(const auto&point:p.polygon())radius=std::max(radius,std::hypot(point[0],point[1]));
        radius+=p.value("clearance_margin_m")+p.value("payload_extra_margin_m");
        bool risk=false;for(const auto&v:{command_,measured_}){
          double horizon=stopping_horizon(v,p.value("reaction_time_s"),p.value("brake_deceleration_m_s2"),p.value("angular_brake_deceleration_rad_s2"),p.value("linear_stop_delay_s"));
          risk=risk||astribot_navigation_zones::sweptCircleBlocked(snapshot->regions,transform.transform.translation.x,transform.transform.translation.y,yaw,v[0],v[1],v[2],radius,horizon);
        }
        if(risk){independent_stop=true;reason="ZONES_SWEEP_RISK";}zone_reason="ZONES_APPLIED";
      }catch(...){installed=false;zone_reason="ZONES_TF_OR_GEOMETRY_UNAVAILABLE";}
      if(snapshot)zone_ack_->publish(astribot_navigation_zones::acknowledgement(*snapshot,"protection",installed,zone_reason));
      if(!installed||!zones_.ready()){independent_stop=true;reason=installed?"ZONES_WAIT_APPLICATION":zone_reason;}
    }
    if(!camera_status.ready){independent_stop=true;reason=camera_status.reason;}
    if (!timing.running) { independent_stop = true; reason = "SIM_CLOCK_STALLED"; }
    if (independent_stop) clear_at_.reset();
    else if (!clear_at_) clear_at_ = timing.now;
    bool stop = independent_stop || !lease || (proposal_ && proposal_->hold);
    if (!stop && timing.now - *clear_at_ < p.value("clear_hold_s")) { stop = true; reason = "PROTECTION_CLEAR_CONFIRMATION"; }
    auto command = clock_->command_fresh(command_ros_at_, command_at_, p.value("input_command_timeout_s"), seconds_now, wall)
      ? command_ : std::vector<double>{0., 0., 0.};
    if (lease && proposal_->alignment_required) command[0] = command[1] = 0.;
    if (lease && proposal_->centering_required) command[2] = 0.;
    const double cap = lease ? std::min(p.value("max_speed_m_s"), proposal_->max_linear_speed) : 0.;
    const double angular_cap = lease ? proposal_->max_angular_speed : 0.;
    // Re-anchor only after the expensive protection/zone calculations. A new
    // wire stamp must not renew the policy evidence behind an older proposal.
    const auto publication_anchor = now();
    const auto publication_wall = steady_seconds();
    const auto proposal_stamp_ns = proposal_ ? valid_ns(proposal_->stamp) : 0;
    const bool proposal_stamp_valid = proposal_ && proposal_->stamp.sec >= 0 &&
      proposal_->stamp.nanosec < 1000000000u;
    const auto proposal_deadline = proposal_stamp_valid ?
      conservative_publication_deadline(proposal_stamp_ns, proposal_->lease_s) : std::nullopt;
    // These are the exact scan/odom samples already used above. Callbacks are
    // serialized; no newer evidence is substituted to refresh an old result.
    const auto scan_deadline = conservative_source_deadline(scan_stamp_ns_, p.value("sensor_timeout_s"));
    const auto odom_deadline = conservative_source_deadline(odom_stamp_ns_, p.value("sensor_timeout_s"));
    const bool publication_inputs_fresh =
      clock_->fresh(scan_stamp_, scan_at_, p.value("sensor_timeout_s"), publication_anchor.seconds(), publication_wall) &&
      clock_->fresh(odom_stamp_, odom_at_, p.value("sensor_timeout_s"), publication_anchor.seconds(), publication_wall);
    const bool publication_proposal_fresh = proposal_ &&
      clock_->fresh(seconds(proposal_->stamp), proposal_at_, proposal_->lease_s,
        publication_anchor.seconds(), publication_wall);
    const bool intervals_valid = proposal_deadline && scan_deadline && odom_deadline;
    const auto publication = evaluate_publication_lease(
      publication_anchor.nanoseconds(), ros.nanoseconds(), decision_epoch, epoch_,
      p.value("constraint_lease_s"),
      intervals_valid ? std::vector<std::array<std::int64_t, 2>>{
        {proposal_stamp_ns, *proposal_deadline}, {scan_stamp_ns_, *scan_deadline},
        {odom_stamp_ns_, *odom_deadline}} : std::vector<std::array<std::int64_t, 2>>{},
      lease && intervals_valid && publication_inputs_fresh && publication_proposal_fresh);
    if (!publication.allowed) {
      // Same-tick revocation reaches the limiter before any command is output.
      // Preserve a pre-existing independent reason when already stopped.
      if (!stop) reason = "POLICY_PUBLICATION_" + publication.reason;
      stop = true;
      if (!publication_inputs_fresh || !scan_deadline || !odom_deadline ||
          publication_anchor.nanoseconds() < ros.nanoseconds() || decision_epoch != epoch_) {
        clear_at_.reset();
      }
    }
    const double hold_lease_s = p.value("constraint_lease_s");
    const auto output = restriction_.apply(command, cap, angular_cap, stop, timing.dt,
      p.value("max_acceleration_m_s2"), p.value("max_angular_acceleration_rad_s2"), clock_->simulated());
    Twist message; message.linear.x = output[0]; message.linear.y = output[1]; message.angular.z = output[2];
    const auto output_publish_start_ns = now().nanoseconds();
    output_->publish(message);
    ++sequence_;
    Constraint c; c.stamp = publication_anchor; c.epoch = epoch_; c.sequence = sequence_;
    c.lease_s = stop ? hold_lease_s : publication.lease_s;
    c.hold = stop; c.reason = reason; c.max_linear_speed = stop ? 0. : cap;
    c.max_angular_speed = stop ? 0. : angular_cap; c.planning = !stop && lease ? proposal_->planning : 0;
    c.alignment_required = !stop && lease && proposal_->alignment_required;
    c.centering_required = !stop && lease && proposal_->centering_required;
    c.corridor_tracking_required = !stop && lease && proposal_->corridor_tracking_required;
    const auto constraint_publish_start_ns = now().nanoseconds();
    constraint_->publish(c);
    if (timing_diagnostics_ || sequence_ % 5 == 0) {
      nlohmann::json data{{"reason", reason}, {"hold", stop},
        {"constraint_epoch",c.epoch},{"constraint_sequence",c.sequence},
        {"proposal_epoch",proposal_ ? nlohmann::json(proposal_->epoch) : nlohmann::json(nullptr)},
        {"proposal_sequence",proposal_ ? nlohmann::json(proposal_->sequence) : nlohmann::json(nullptr)},
        {"proposal_stamp_ns",proposal_ ? nlohmann::json(proposal_stamp_ns) : nlohmann::json(nullptr)},
        {"proposal_deadline_ns",proposal_deadline ? nlohmann::json(*proposal_deadline) : nlohmann::json(nullptr)},
        {"publication_stamp_ns",publication_anchor.nanoseconds()},
        {"publication_wall_s",publication_wall},{"publication_inputs_fresh",publication_inputs_fresh},
        {"publication_proposal_fresh",publication_proposal_fresh},
        {"scan_capture_ns",scan_stamp_ns_},{"odom_capture_ns",odom_stamp_ns_},
        {"scan_deadline_ns",scan_deadline ? nlohmann::json(*scan_deadline) : nlohmann::json(nullptr)},
        {"odom_deadline_ns",odom_deadline ? nlohmann::json(*odom_deadline) : nlohmann::json(nullptr)},
        {"effective_deadline_ns",publication.deadline_ns},
        {"effective_lease_s",c.lease_s},{"publication_lease_reason",publication.reason},
        {"output_publish_start_ns",output_publish_start_ns},
        {"constraint_publish_start_ns",constraint_publish_start_ns},
        {"projection_ready",camera_status.ready},{"projection_reason",camera_status.reason},
        {"projection_revision",camera_status.revision},{"projection_released_ns",camera_status.released_ns},
        {"projection_future_samples_rejected",camera_status.future_samples_rejected},
        {"scan_age_s", age(seconds_now - scan_stamp_)}, {"scan_wall_age_s", age(wall - scan_at_)},
        {"odom_age_s", age(seconds_now - odom_stamp_)}, {"odom_wall_age_s", age(wall - odom_at_)},
        {"policy_wall_age_s", age(wall - proposal_at_)}, {"loop_wall_dt_s", timing.wall_dt},
        {"loop_control_dt_s", timing.dt}, {"time_domain", clock_->simulated() ? "simulation" : "wall"},
        {"clock_running", timing.running}, {"points", points_.size()}, {"scan_received", scan_received_},
        {"scan_transformed", scan_transformed_}, {"scan_invalid", scan_invalid_}, {"scan_tf_waits", scan_tf_waits_},
        {"scan_expired", scan_expired_}, {"pending_scans", pending_.size()}, {"last_scan_error", last_scan_error_},
        {"limiter_recovering", restriction_.recovering()}, {"input_speed_m_s", age(std::hypot(command_[0], command_[1]))},
        {"output_speed_m_s", std::hypot(output[0], output[1])}};
      std_msgs::msg::String diagnostic; diagnostic.data = data.dump(); diagnostics_->publish(diagnostic);
    }
  }

  bool timing_diagnostics_{false};
  bool require_zones_{false};astribot_navigation_zones::Gate zones_;rclcpp::Publisher<std_msgs::msg::String>::SharedPtr zone_ack_;
  std::unique_ptr<ProjectionCapabilityGate> camera_gate_;uint64_t camera_revision_{0};
  std::vector<rclcpp::SubscriptionBase::SharedPtr> camera_subscriptions_;
  std::unique_ptr<ProtectionProfile> profile_;
  std::unique_ptr<ControlTime> clock_;
  CommandRestriction restriction_;
  std::unique_ptr<tf2_ros::Buffer> tf_;
  std::shared_ptr<tf2_ros::TransformListener> listener_;
  std::vector<double> command_{0., 0., 0.}, measured_{0., 0., 0.}, coverage_;
  std::vector<std::array<double, 2>> points_;
  double command_at_{absent}, command_ros_at_{absent}, odom_at_{absent}, odom_stamp_{absent};
  double scan_at_{absent}, scan_stamp_{absent}, proposal_at_{absent};
  std::int64_t scan_stamp_ns_{-1}, odom_stamp_ns_{-1};
  Constraint::ConstSharedPtr proposal_;
  std::optional<double> clear_at_;
  std::uint64_t sequence_{0}, epoch_{steady_ns()};
  std::uint64_t scan_received_{0}, scan_transformed_{0}, scan_invalid_{0}, scan_tf_waits_{0}, scan_expired_{0};
  std::string last_scan_error_;
  std::vector<Scan::ConstSharedPtr> pending_;
  rclcpp::Publisher<Twist>::SharedPtr output_;
  rclcpp::Publisher<Constraint>::SharedPtr constraint_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr diagnostics_;
  rclcpp::Publisher<ApplyStatus>::SharedPtr ack_;
  rclcpp::Subscription<Twist>::SharedPtr input_;
  rclcpp::Subscription<Odom>::SharedPtr odom_;
  rclcpp::Subscription<Scan>::SharedPtr scan_;
  rclcpp::Subscription<Constraint>::SharedPtr proposal_sub_;
  rclcpp::Subscription<ProtectionEnvelope>::SharedPtr envelope_;
  rclcpp::Subscription<ProtectionEnvelopeV2>::SharedPtr v2_;
  rclcpp::TimerBase::SharedPtr timer_;
};
}  // namespace astribot::navigation

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  try {
    auto node = std::make_shared<astribot::navigation::FinalProtectionNode>();
    rclcpp::spin(node); node->stop(); node.reset(); rclcpp::shutdown();
  } catch (const std::exception& error) {
    RCLCPP_FATAL(rclcpp::get_logger("navigation_final_protection"), "%s", error.what());
    rclcpp::shutdown(); return 1;
  }
  return 0;
}
