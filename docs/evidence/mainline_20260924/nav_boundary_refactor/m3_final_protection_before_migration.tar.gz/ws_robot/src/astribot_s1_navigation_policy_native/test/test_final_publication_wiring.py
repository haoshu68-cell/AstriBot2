"""Offline wiring guards; no ROS process or simulated time is started.

Behavioral deadline/rounding cases live in publication_lease_test.cpp. These
checks stop the final forwarding stage from silently replacing that deadline
with a fresh full lease after expensive protection calculations.
"""
from pathlib import Path
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'src/final_protection_node.cpp'

class FinalPublicationWiring(unittest.TestCase):
    def test_final_constraint_uses_actual_anchor_and_remaining_lease(self):
        source = SOURCE.read_text()
        self.assertIn('const auto publication_anchor = now();', source)
        self.assertIn('c.stamp = publication_anchor;', source)
        self.assertIn('stop ? hold_lease_s : publication.lease_s', source)
        self.assertNotIn('c.stamp = ros;', source)
        self.assertLess(source.index('protection_swept_collision(points_'),
                        source.index('const auto publication_anchor = now();'))
        self.assertLess(source.index('const auto publication_anchor = now();'),
                        source.index('restriction_.apply(command'))

    def test_expired_publication_stops_same_tick_and_revokes_all_motion_flags(self):
        source = SOURCE.read_text()
        self.assertIn('if (!publication.allowed)', source)
        block = source.split('if (!publication.allowed)', 1)[1].split('\n    }', 1)[0]
        self.assertIn('stop = true;', block)
        self.assertIn('clear_at_.reset();', block)
        for field in ('planning', 'alignment_required', 'centering_required', 'corridor_tracking_required'):
            line = next(line for line in source.splitlines() if 'c.' + field + ' =' in line)
            self.assertIn('!stop &&', line)

    def test_wire_diagnostic_identifies_upstream_and_effective_publication(self):
        source = SOURCE.read_text()
        for key in ('proposal_epoch', 'proposal_sequence', 'proposal_stamp_ns',
                    'proposal_deadline_ns', 'publication_stamp_ns', 'effective_lease_s',
                    'publication_lease_reason', 'output_publish_start_ns', 'constraint_publish_start_ns'):
            self.assertIn('"' + key + '"', source)
        self.assertIn('if (timing_diagnostics_ || sequence_ % 5 == 0)', source)

if __name__ == '__main__':
    unittest.main()
