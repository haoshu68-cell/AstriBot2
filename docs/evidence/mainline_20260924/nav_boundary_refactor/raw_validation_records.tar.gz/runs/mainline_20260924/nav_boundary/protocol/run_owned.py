"""One-off isolated protocol launcher; records its own child identities only."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
command=sys.argv[2:]
assert os.environ.get('ROS_DOMAIN_ID')=='36'
assert os.environ.get('ROS_LOCALHOST_ONLY')=='1'
def identity(pid):
    try:
        path=Path('/proc')/str(pid)
        stat=(path/'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'ppid':int(stat[1]),'start_ticks':stat[19],
                'argv':(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
    except (FileNotFoundError,PermissionError,ProcessLookupError):
        return None
started=time.time_ns(); seen={}
with (out/'stdout.log').open('w') as log:
    child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
    while child.poll() is None:
        rows=[row for p in Path('/proc').iterdir() if p.name.isdecimal()
              if (row:=identity(int(p.name))) is not None]
        parents={child.pid}
        while True:
            added={row['pid'] for row in rows if row['ppid'] in parents}-parents
            if not added:break
            parents.update(added)
        for row in rows:
            if row['pid'] in parents:seen[(row['pid'],row['start_ticks'])]=row
        time.sleep(.1)
    returncode=child.wait()
alive=[]
for key,row in seen.items():
    current=identity(row['pid'])
    if current and current['start_ticks']==row['start_ticks']:alive.append(current)
result={'command':command,'started_ns':started,'finished_ns':time.time_ns(),
        'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        'environment':{k:os.environ.get(k) for k in ('ROS_DOMAIN_ID','ROS_LOCALHOST_ONLY',
             'RMW_IMPLEMENTATION','AMENT_PREFIX_PATH','LD_LIBRARY_PATH','PYTHONPATH')},
        'returncode':returncode,'observed_owned_processes':list(seen.values()),'still_alive':alive}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'returncode':returncode,'processes':len(seen),'still_alive':len(alive),'path':str(out)}))
sys.exit(returncode if returncode else (1 if alive else 0))
