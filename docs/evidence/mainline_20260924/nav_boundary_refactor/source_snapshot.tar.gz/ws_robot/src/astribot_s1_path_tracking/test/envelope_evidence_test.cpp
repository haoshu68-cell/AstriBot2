#include <cassert>
#include "astribot_s1_path_tracking/envelope_evidence.hpp"
using E=astribot_s1_path_tracking::EnvelopeEvidence;
auto message(int stamp,int until=1300000000) {
 auto m=std::make_shared<E::Message>();m->header.stamp.sec=stamp/1000000000;
 m->header.stamp.nanosec=stamp%1000000000;m->limits.stamp=m->header.stamp;
 m->valid_until.sec=until/1000000000;m->valid_until.nanosec=until%1000000000;
 m->coordinator_session_id="session";m->installed_geometry_hash="geometry";
 m->epoch=1;m->navigation_allowed=m->limits.transport_ready=true;m->limits.lease_s=.3;
 return m;
}
int main() {
 E gate;const auto t=E::Wall::now();auto old=message(1000000000),next=message(1100000000,1400000000);
 gate.accept(old,1000000000,t);gate.accept(next,1099000000,t+std::chrono::milliseconds(5));
 assert(gate.sample(1099000000).message==old);assert(gate.sample(1099000000).received==t);
 assert(gate.sample(1100000000).message==next);
 auto far=message(2000000000,2100000000);gate.accept(far,1200000000,t);
 assert(gate.sample(1500000000).message==next); // original expired deadline remains unchanged
 auto revoke=message(1900000000,2000000000);revoke->navigation_allowed=false;
 gate.accept(revoke,1500000000,t);assert(gate.sample(1500000000).message==revoke);
 assert(gate.sample(2000000000).message==revoke); // queued old permission cannot revive
 E changed;changed.accept(old,1000000000,t);auto new_epoch=message(1100000000);new_epoch->epoch=2;
 changed.accept(new_epoch,1099000000,t);assert(changed.sample(1099000000).message==new_epoch);
 changed.accept(old,1100000000,t);assert(changed.sample(1100000000).message==new_epoch);
 E shortened;shortened.accept(old,1000000000,t);next=message(1100000000,1200000000);
 shortened.accept(next,1099000000,t);assert(shortened.sample(1099000000).message==next);
 E rewind;rewind.accept(old,1000000000,t);assert(!rewind.sample(900000000).message);
 rewind.accept(old,1100000000,t);assert(!rewind.sample(1100000000).message);
 auto recovered=message(1100000000);recovered->clock_epoch=1;
 rewind.accept(recovered,1100000000,t);assert(rewind.sample(1100000000).message==recovered);

 auto ready=message(1000000000,1500000000);
 ready->mode=E::Message::FIXED_POSTURE;ready->header.frame_id="astribot_torso_base";
 ready->hold_id="hold";ready->attachment_revision="attachment";ready->model_revision="model";ready->request_id="request";
 const std::string base="astribot_torso_base";
 assert(E::navigationReason({ready,t},base,1000000000,t).empty());
 assert(E::navigationReason({},base,1000000000,t)=="ENVELOPE_MISSING");
 auto invalid=std::make_shared<E::Message>(*ready);invalid->mode=E::Message::HOLD;
 assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_MODE_MISMATCH");
 assert(E::navigationReason({ready,t},"other_base",1000000000,t)=="ENVELOPE_FRAME_MISMATCH");
 for(auto field:{&E::Message::coordinator_session_id,&E::Message::installed_geometry_hash}) {
   invalid=std::make_shared<E::Message>(*ready);(invalid.get()->*field).clear();
   assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_IDENTITY_MISSING");
 }
 invalid=std::make_shared<E::Message>(*ready);invalid->header.stamp={};
 assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_SOURCE_INVALID");
 assert(E::navigationReason({ready,t},base,999999999,t)=="ENVELOPE_FUTURE");
 assert(E::navigationReason({ready,t},base,1300000000,t).empty());
 assert(E::navigationReason({ready,t},base,1300000001,t)=="ENVELOPE_ROS_STALE");
 assert(E::navigationReason({ready,t},base,1000000000,t+std::chrono::milliseconds(500)).empty());
 assert(E::navigationReason({ready,t},base,1000000000,t+std::chrono::nanoseconds(500000001))=="ENVELOPE_WALL_STALE");
 invalid=std::make_shared<E::Message>(*ready);invalid->valid_until=invalid->header.stamp;
 assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_EXPIRED");
 invalid=std::make_shared<E::Message>(*ready);invalid->navigation_allowed=false;invalid->reason="ARM_HOLD_UNCONFIRMED";
 assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_REVOKED: ARM_HOLD_UNCONFIRMED");
 invalid=std::make_shared<E::Message>(*ready);invalid->limits.transport_ready=false;invalid->reason="TASK_HOLD";
 assert(E::navigationReason({invalid,t},base,1000000000,t)=="ENVELOPE_REVOKED: TASK_HOLD");

 auto heartbeat=*ready;heartbeat.header.stamp.nanosec=1;heartbeat.limits.stamp.nanosec=1;
 heartbeat.valid_until.nanosec=600000000;heartbeat.source_state_sequence=100;
 assert(E::sameExecution(*ready,heartbeat));
 for(auto field:{&E::Message::coordinator_session_id,&E::Message::installed_geometry_hash,
     &E::Message::hold_id,&E::Message::attachment_revision,&E::Message::model_revision,&E::Message::request_id}) {
   auto changed=*ready;changed.*field+="changed";assert(!E::sameExecution(*ready,changed));
 }
 auto identity=*ready;++identity.epoch;assert(!E::sameExecution(*ready,identity));
 identity=*ready;++identity.clock_epoch;assert(!E::sameExecution(*ready,identity));
}
