#pragma once
#include <chrono>
#include <deque>
#include <string>
#include "astribot_navigation_msgs/msg/navigation_envelope_v2.hpp"

namespace astribot_s1_path_tracking {
// Shared timing and navigation authority evidence; geometry stays with its consumers.
class EnvelopeEvidence {
public:
  using Message=astribot_navigation_msgs::msg::NavigationEnvelopeV2;
  using Wall=std::chrono::steady_clock;
  struct Sample {Message::ConstSharedPtr message;Wall::time_point received;};
  static std::string navigationReason(const Sample & sample,const std::string & base,
      int64_t now_ns,Wall::time_point now_wall) {
    const auto & message=sample.message;
    if(!message)return "ENVELOPE_MISSING";
    if(message->mode!=Message::FIXED_POSTURE)return "ENVELOPE_MODE_MISMATCH";
    if(message->header.frame_id!=base)return "ENVELOPE_FRAME_MISMATCH";
    if(message->coordinator_session_id.empty() || message->installed_geometry_hash.empty())
      return "ENVELOPE_IDENTITY_MISSING";
    const auto source=ns(message->header.stamp);
    if(source<=0)return "ENVELOPE_SOURCE_INVALID";
    if(source>now_ns)return "ENVELOPE_FUTURE";
    if(now_ns-source>300000000LL)return "ENVELOPE_ROS_STALE";
    if(now_wall-sample.received>std::chrono::milliseconds(500))return "ENVELOPE_WALL_STALE";
    if(now_ns>=ns(message->valid_until))return "ENVELOPE_EXPIRED";
    if(!message->navigation_allowed || !message->limits.transport_ready)return "ENVELOPE_REVOKED: "+message->reason;
    return {};
  }
  static bool sameExecution(const Message & a,const Message & b) {
    return a.coordinator_session_id==b.coordinator_session_id && a.epoch==b.epoch &&
      a.installed_geometry_hash==b.installed_geometry_hash && a.clock_epoch==b.clock_epoch &&
      a.hold_id==b.hold_id && a.attachment_revision==b.attachment_revision &&
      a.model_revision==b.model_revision && a.request_id==b.request_id;
  }
  void accept(Message::ConstSharedPtr message,int64_t now,Wall::time_point received) {
    observeClock(now);
    if(clock_fault_) {
      if(message->clock_epoch==fault_epoch_ && message->coordinator_session_id==fault_session_)return;
      clock_fault_=false;
    }
    const auto newest=pending_.empty()?current_.message:pending_.back().message;
    if(newest && message->coordinator_session_id==newest->coordinator_session_id) {
      if(message->epoch<newest->epoch)return;
      if(message->epoch==newest->epoch && message->installed_geometry_hash!=newest->installed_geometry_hash) {
        clear();return;
      }
    }
    if(newest && sameAuthority(*newest,*message) && newest->navigation_allowed &&
      newest->limits.transport_ready && message->navigation_allowed && message->limits.transport_ready &&
      ns(message->valid_until)>=ns(newest->valid_until) &&
      (ns(message->header.stamp)>now || ns(message->limits.stamp)>now))
    {
      pending_.push_back({message,received});
      if(pending_.size()>8)pending_.pop_front();
      return;
    }
    pending_.clear();current_={message,received};
  }
  Sample sample(int64_t now) {
    observeClock(now);
    if(clock_fault_)return {};
    for(auto it=pending_.begin();it!=pending_.end();) {
      if(ns(it->message->header.stamp)<=now && ns(it->message->limits.stamp)<=now) {
        if(!current_.message || ns(it->message->header.stamp)>=ns(current_.message->header.stamp))current_=*it;
        it=pending_.erase(it);
      }else ++it;
    }
    return current_;
  }
  void clear() {current_={};pending_.clear();}
private:
  void observeClock(int64_t now) {
    if(last_now_>=0 && now<last_now_) {
      const auto newest=pending_.empty()?current_.message:pending_.back().message;
      if(newest){fault_epoch_=newest->clock_epoch;fault_session_=newest->coordinator_session_id;}
      clear();clock_fault_=true;
    }
    last_now_=now;
  }
  static int64_t ns(const builtin_interfaces::msg::Time & t) {
    return static_cast<int64_t>(t.sec)*1000000000LL+t.nanosec;
  }
  static bool sameAuthority(Message a,Message b) {
    a.header.stamp={};b.header.stamp={};a.limits.stamp={};b.limits.stamp={};
    a.valid_until={};b.valid_until={};a.source_state_sequence=0;b.source_state_sequence=0;
    return a==b;
  }
  Sample current_{};
  std::deque<Sample> pending_;
  int64_t last_now_{-1};bool clock_fault_{false};uint64_t fault_epoch_{0};std::string fault_session_;
};
}  // namespace astribot_s1_path_tracking
