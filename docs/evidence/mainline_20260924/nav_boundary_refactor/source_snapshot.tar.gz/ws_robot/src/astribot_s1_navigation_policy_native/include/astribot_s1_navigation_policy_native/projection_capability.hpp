#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <stdexcept>
#include <map>
#include <optional>
#include <cmath>
#include <cctype>
#include <algorithm>
namespace astribot::navigation {
struct CameraCapabilitySample {
  std::string camera,frame,epoch;
  bool valid{false};
  int64_t header_ns{0},capture_ns{0},until_ns{0};
};
struct ProjectionCapabilityStatus {
  bool ready{false};
  std::string reason{"CAMERA_PROJECTION_UNAVAILABLE"};
  uint64_t revision{0};
  uint64_t future_samples_rejected{0};
  int64_t released_ns{0};
};
class ProjectionCapabilityGate {
 public:
  explicit ProjectionCapabilityGate(const std::vector<std::string>& cameras) {
    if(cameras.size()>16)throw std::invalid_argument("too many projection sources");
    for(const auto& camera:cameras) {
      if(camera.empty()||camera.size()>64||!std::all_of(camera.begin(),camera.end(),[](unsigned char c){return std::isalnum(c)||c=='_';})||
         !sources_.emplace(camera,Source{}).second)throw std::invalid_argument("invalid/duplicate projection camera");
    }
  }
  bool enabled()const{return !sources_.empty();}
  void raw(const CameraCapabilitySample& s,int64_t now,double wall) {receive(s,now,wall,false);}
  void processing(const CameraCapabilitySample& s,int64_t now,double wall) {receive(s,now,wall,true);}
  ProjectionCapabilityStatus evaluate(int64_t now,double wall) {
    if(!enabled()){status_.ready=true;status_.reason="DISABLED";return status_;}
    observe_clock(now);
    for(const auto& [camera,source]:sources_) {
      if(!fresh(source.raw,now,wall)){block("CAMERA_HEALTH_INVALID:"+camera,now);return status_;}
      if(!fresh(source.processing,now,wall)){block("PROJECTION_HEALTH_INVALID:"+camera,now);return status_;}
      if(source.raw->sample.frame!=source.processing->sample.frame){block("CAMERA_PROJECTION_FRAME_MISMATCH:"+camera,now);return status_;}
      if(source.raw->sample.capture_ns<=fault_after_||source.processing->sample.capture_ns<=fault_after_){
        block("PROJECTION_WAIT_NEW_CAPTURE:"+camera,now);return status_;
      }
    }
    if(!status_.ready){status_.ready=true;++status_.revision;status_.released_ns=now;}
    status_.reason="CAMERA_PROJECTION_READY";return status_;
  }
 private:
  struct Received {CameraCapabilitySample sample;double received_wall,capture_wall;};
  struct Source {std::optional<Received> raw,processing;};
  std::map<std::string,Source> sources_;
  ProjectionCapabilityStatus status_;
  int64_t last_now_=0,fault_after_=0;
  void observe_clock(int64_t now) {
    if(last_now_&&now<last_now_) {
      for(auto& [id,source]:sources_){(void)id;source=Source{};}
      status_.ready=false;++status_.revision;status_.released_ns=0;fault_after_=now;status_.reason="PROJECTION_CLOCK_ROLLBACK";
    }
    last_now_=now;
  }
  void block(const std::string& reason,int64_t now) {
    if(status_.ready){++status_.revision;fault_after_=now;status_.released_ns=0;}
    status_.ready=false;status_.reason=reason;
  }
  static bool fresh(const std::optional<Received>& value,int64_t now,double wall) {
    if(!value)return false;
    const auto& r=*value;const auto& s=r.sample;
    return s.valid&&s.capture_ns>0&&s.capture_ns<=s.header_ns&&s.header_ns<=now&&
      now-s.capture_ns<=250000000LL&&s.until_ns>s.capture_ns&&s.until_ns<=s.capture_ns+500000000LL&&now<s.until_ns&&
      std::isfinite(wall)&&wall>=r.received_wall&&wall-r.received_wall<=.25&&wall>=r.capture_wall&&wall-r.capture_wall<=.25;
  }
  void receive(const CameraCapabilitySample& s,int64_t now,double wall,bool processing) {
    observe_clock(now);auto found=sources_.find(s.camera);if(found==sources_.end())return;
    auto& slot=processing?found->second.processing:found->second.raw;
    if(slot&&s.header_ns<slot->sample.header_ns)return;
    // /clock and health travel independently. A same-context heartbeat ahead
    // of our clock is not admissible and cannot refresh the previous lease.
    // It also must not revoke a still-fresh previous capture. Explicit faults
    // and changed identities continue through the revocation path below.
    if(s.header_ns>now&&s.valid&&(!slot||(s.frame==slot->sample.frame&&s.epoch==slot->sample.epoch))) {
      ++status_.future_samples_rejected;return;
    }
    if(s.frame.empty()||s.frame.size()>512||s.epoch.empty()||s.epoch.size()>512||
       s.capture_ns<=0||s.capture_ns>s.header_ns||s.header_ns>now||!std::isfinite(wall)) {
      slot.reset();block("CAMERA_PROJECTION_INVALID_SAMPLE:"+s.camera,now);return;
    }
    const bool changed=slot&&(s.epoch!=slot->sample.epoch||s.frame!=slot->sample.frame);
    if(!s.valid||changed)block(changed?"CAMERA_PROJECTION_CONTEXT_CHANGED:"+s.camera:"CAMERA_PROJECTION_REVOKED:"+s.camera,now);
    if(slot&&!changed&&s.capture_ns<slot->sample.capture_ns){slot.reset();block("CAMERA_PROJECTION_CAPTURE_REGRESSED:"+s.camera,now);return;}
    const double capture_wall=slot&&!changed&&s.capture_ns==slot->sample.capture_ns?slot->capture_wall:wall;
    slot=Received{s,wall,capture_wall};
  }
};
}
