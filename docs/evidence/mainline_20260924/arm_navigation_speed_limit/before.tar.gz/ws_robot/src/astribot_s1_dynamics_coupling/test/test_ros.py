"""Owned real-ROS processes; frozen Python A/B oracle; deterministic /clock input.

Every child is in ROS_DOMAIN_ID 140 (override only within 140..144), localhost.
No ros2 daemon, simulator, shared overlay, process-name cleanup, or bindings.
"""
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

import pytest

HERE = Path(__file__).resolve().parent


def oracle_main():
    sys.path.insert(0, str(HERE / 'reference'))
    os.environ['ASTRIBOT_BRIDGE_NATIVE_KERNELS'] = '0'
    from astribot_s1_dynamics_coupling.arm_chassis_speed_coupling_node import main
    main(args=sys.argv[2:])


class Pair:
    def __init__(self, case, metric='joint_deviation', params=None, implementations=('python', 'cpp')):
        import rclpy
        from geometry_msgs.msg import Twist, TransformStamped
        from sensor_msgs.msg import JointState
        from rosgraph_msgs.msg import Clock
        from rcl_interfaces.srv import SetParametersAtomically
        from tf2_ros import TransformBroadcaster, StaticTransformBroadcaster
        self.rclpy = rclpy
        self.Twist, self.JointState, self.TransformStamped, self.Clock = Twist, JointState, TransformStamped, Clock
        self.service = SetParametersAtomically
        self.prefix = 'coupling_' + uuid.uuid4().hex[:10]
        self.node = rclpy.create_node(self.prefix)
        self.output = Path(os.environ.get('DYNAMICS_EVIDENCE', '/tmp/codex_dynamics_coupling_20260921/ros')) / case
        self.output.mkdir(parents=True, exist_ok=True)
        self.clock = self.node.create_publisher(Clock, '/clock', 10)
        self.joint_pub = self.node.create_publisher(JointState, '/' + self.prefix + '/joints', 10)
        self.cmd_pub = self.node.create_publisher(Twist, '/' + self.prefix + '/input_remapped', 10)
        self.tf = TransformBroadcaster(self.node)
        self.static_tf = StaticTransformBroadcaster(self.node)
        self.processes, self.handles, self.subscriptions, self.steps = [], [], [], []
        self.values, self.clients = {}, {}
        self.stamp = 10 * 10**9
        self.domain = os.environ.get('DYNAMICS_DOMAIN', '140')
        assert 140 <= int(self.domain) <= 144
        binary = Path(os.environ.get('DYNAMICS_CPP', '/missing/arm_chassis_speed_coupling_node'))
        assert 'cpp' not in implementations or binary.is_file(), 'Native ROS executable is not implemented/built'
        try:
            for implementation in implementations:
                ns = '/' + self.prefix + '/' + implementation
                self.values[implementation] = []
                self.subscriptions.append(self.node.create_subscription(Twist, ns + '/output_remapped',
                    lambda message, key=implementation: self.values[key].append((time.perf_counter_ns(), message)), 100))
                parameters = {'extension_metric': metric, 'input_topic': '/' + self.prefix + '/input',
                              'output_topic': ns + '/output', 'joint_states_topic': '/' + self.prefix + '/joints',
                              'chassis_base_frame': self.frame('base'), 'monitored_links': [self.frame('reach')],
                              'use_sim_time': True, 'log_throttle_sec': 1000.0}
                parameters.update(params or {})
                # YAML preserves declared double-array types, including a test's empty array update.
                import yaml
                config = self.output / (implementation + '_params.yaml')
                config.write_text(yaml.safe_dump({'/**': {'ros__parameters': parameters}}))
                args = ['--ros-args', '-r', '__ns:=' + ns, '--params-file', str(config),
                        '-r', '/' + self.prefix + '/input:=/' + self.prefix + '/input_remapped',
                        '-r', ns + '/output:=' + ns + '/output_remapped']
                command = ([sys.executable, str(HERE / 'test_ros.py'), '--oracle'] if implementation == 'python' else [str(binary)]) + args
                env = os.environ.copy()
                env.update(ROS_DOMAIN_ID=self.domain, ROS_LOCALHOST_ONLY='1', ASTRIBOT_BRIDGE_NATIVE_KERNELS='0',
                           ROS_LOG_DIR=str(self.output / 'ros_logs'))
                handle = (self.output / (implementation + '.log')).open('w')
                self.handles.append(handle)
                child = subprocess.Popen(command, stdout=handle, stderr=subprocess.STDOUT, env=env)
                self.processes.append((implementation, child, command))
                self.clients[implementation] = self.node.create_client(SetParametersAtomically,
                    ns + '/arm_chassis_speed_coupling_node/set_parameters_atomically')
            self.until(lambda: all(client.service_is_ready() for client in self.clients.values()), 10)
            self.until(lambda: self.cmd_pub.get_subscription_count() == len(implementations) and
                       self.joint_pub.get_subscription_count() == len(implementations), 5)
            for implementation, child, _ in self.processes:
                environ = Path('/proc', str(child.pid), 'environ').read_bytes().split(b'\0')
                assert ('ROS_DOMAIN_ID=' + self.domain).encode() in environ
                assert b'ROS_LOCALHOST_ONLY=1' in environ
                if implementation == 'cpp':
                    maps = Path('/proc', str(child.pid), 'maps').read_text()
                    assert 'libpython' not in maps and '_chassis_math_native' not in maps
            self.set_clock(self.stamp)
        except BaseException:
            self.close(require_zero=False)
            raise

    def frame(self, name):
        return self.prefix + '_' + name

    def pump(self, duration):
        end = time.monotonic() + duration
        while time.monotonic() < end:
            for key, child, _ in self.processes:
                assert child.poll() is None, (key, child.returncode, str(self.output))
            self.rclpy.spin_once(self.node, timeout_sec=min(.01, max(0., end-time.monotonic())))

    def until(self, predicate, timeout=3):
        end = time.monotonic() + timeout
        while not predicate() and time.monotonic() < end:
            self.pump(.01)
        assert predicate(), 'ROS timeout: ' + str(self.output)

    def set_clock(self, ns):
        self.stamp = int(ns)
        message = self.Clock()
        message.clock.sec, message.clock.nanosec = divmod(self.stamp, 10**9)
        for _ in range(4):
            self.clock.publish(message)
            self.pump(.015)

    def joint(self, positions=(0.,), velocities=(), names=None):
        msg = self.JointState()
        msg.header.stamp.sec, msg.header.stamp.nanosec = divmod(self.stamp, 10**9)
        msg.name = list(names if names is not None else ['astribot_arm_left_joint_1'])
        msg.position = list(positions)
        msg.velocity = list(velocities)
        self.joint_pub.publish(msg)
        self.pump(.07)

    def transform(self, reach, *, parent='base', child='reach', stamp=None, static=False, z=0.):
        msg = self.TransformStamped()
        msg.header.frame_id, msg.child_frame_id = self.frame(parent), self.frame(child)
        msg.header.stamp.sec, msg.header.stamp.nanosec = divmod(self.stamp if stamp is None else stamp, 10**9)
        msg.transform.translation.x, msg.transform.translation.z = float(reach), float(z)
        msg.transform.rotation.w = 1.
        (self.static_tf if static else self.tf).sendTransform(msg)
        self.pump(.08)

    def set(self, **values):
        from rclpy.parameter import Parameter
        parameters = []
        for name, value in values.items():
            if value == []:
                kind = Parameter.Type.STRING_ARRAY if name == 'monitored_links' else Parameter.Type.DOUBLE_ARRAY
                parameters.append(Parameter(name, type_=kind, value=value).to_parameter_msg())
            else:
                parameters.append(Parameter(name, value=value).to_parameter_msg())
        futures = {key: client.call_async(self.service.Request(parameters=parameters)) for key, client in self.clients.items()}
        self.until(lambda: all(f.done() for f in futures.values()))
        accepted = {key: f.result().result.successful for key, f in futures.items()}
        self.steps.append({'parameters_repr': {k: repr(v) for k,v in values.items()}, 'accepted': accepted})
        assert all(accepted.values()), accepted

    def expect(self, scale, label):
        start = {key: len(v) for key, v in self.values.items()}
        msg = self.Twist()
        msg.linear.x, msg.linear.y, msg.linear.z = 1., -2., 4.
        msg.angular.x, msg.angular.y, msg.angular.z = 5., 6., 3.
        self.cmd_pub.publish(msg)
        self.until(lambda: all(len(self.values[key]) > start[key] for key in start))
        observed = {}
        for key in start:
            out = self.values[key][-1][1]
            actual = [out.linear.x, out.linear.y, out.linear.z, out.angular.x, out.angular.y, out.angular.z]
            expected = [scale, -2*scale, 0., 0., 0., 3*scale]
            observed[key] = actual
            assert actual == pytest.approx(expected, rel=1e-12, abs=1e-12, nan_ok=True), (key, label, actual, expected)
        self.steps.append({'case': label, 'clock_ns': self.stamp, 'expected_scale': scale, 'observed': observed})

    def close(self, require_zero=True):
        cleanup = []
        for key, child, command in self.processes:
            if child.poll() is None:
                child.send_signal(signal.SIGINT)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    child.terminate()
                    try: child.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        child.kill(); child.wait(timeout=2)
            cleanup.append({'implementation': key, 'pid': child.pid, 'command': command,
                            'exit_code': child.returncode, 'owned_pid_reaped': child.poll() is not None})
        for handle in self.handles: handle.close()
        (self.output / 'result.json').write_text(json.dumps({'domain': self.domain, 'localhost_only': True,
            'steps': self.steps, 'cleanup': cleanup, 'output_counts': {k:len(v) for k,v in self.values.items()}}, indent=2) + '\n')
        self.node.destroy_node()
        if require_zero:
            assert all(row['exit_code'] == 0 for row in cleanup), cleanup


@pytest.fixture
def make_pair(request):
    import rclpy
    os.environ['ROS_DOMAIN_ID'] = os.environ.get('DYNAMICS_DOMAIN', '140')
    os.environ['ROS_LOCALHOST_ONLY'] = '1'
    rclpy.init()
    pairs = []
    def create(metric='joint_deviation', params=None):
        obj = Pair(request.node.name, metric, params)
        pairs.append(obj)
        return obj
    try: yield create
    finally:
        for pair in pairs: pair.close()
        if rclpy.ok(): rclpy.shutdown()


def test_joint_smoothing_empty_partial_duplicate_and_velocity(make_pair):
    p = make_pair()
    p.expect(.3, 'no joint input degraded')
    p.joint([1.2]); p.expect(.7875, 'first EMA full activity')
    p.joint([1.2]); p.expect(.628125, 'second EMA full activity')
    p.set(scale_smoothing_alpha=1.)
    p.joint([], [], []); p.expect(1., 'empty legacy joint input is zero activity')
    p.joint([0.], [2.]); p.expect(.15, 'velocity dimension independently full')
    p.joint([0.], [2., 0.]); p.expect(1., 'malformed velocity length discards all velocities')
    p.joint([1.2, 0.], [], ['astribot_arm_left_joint_1']*2); p.expect(1., 'duplicate last wins')
    p.joint([0.], [], ['unmonitored']); p.expect(1., 'unknown names skipped')
    p.joint([0.], [], ['astribot_arm_left_joint_1', 'astribot_arm_right_joint_1']); p.expect(1., 'position zip truncates')
    n = {k:len(v) for k,v in p.values.items()}; p.pump(.15)
    assert n == {k:len(v) for k,v in p.values.items()}, 'no timer output without incoming Twist'


def test_joint_dynamic_parameters_wrap_and_startup_only_metric(make_pair):
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    p.joint([.6]); p.expect(.575, 'half extension')
    p.set(folded_reference_rad=[.6]); p.joint([.6]); p.expect(1., 'dynamic reference length zip')
    p.set(folded_reference_rad=[]); p.joint([4.]); p.expect(1., 'empty reference zip')
    p.set(folded_reference_rad=[math.pi]); p.joint([-math.pi]); p.expect(.15, 'raw angle difference, no wrap')
    p.set(folded_reference_rad=[0.], extension_full_rad=2., min_speed_scale=.4)
    p.joint([1.]); p.expect(.7, 'dynamic joint full and minimum')
    p.set(velocity_full_rad_s=4.); p.joint([0.], [1.]); p.expect(.85, 'dynamic velocity full')
    p.set(extension_metric='horizontal_reach', input_topic='/unused_input', output_topic='/unused_output', joint_states_topic='/unused_joints')
    p.joint([0.]); p.expect(1., 'metric and topic changes are startup-only')
    p.set(log_throttle_sec=0.); p.joint([2.]); p.expect(.4, 'dynamic logging parameter accepted')


def test_clock_timeout_exact_boundary_rollback_and_dynamic_degraded(make_pair):
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    p.joint([0.]); p.expect(1., 'fresh')
    p.set_clock(10_500_000_000); p.expect(1., 'age exactly timeout still fresh')
    p.set_clock(10_500_000_001); p.expect(.3, 'one nanosecond beyond timeout degraded')
    p.set(degraded_scale=.22); p.expect(.22, 'dynamic degraded scale')
    p.set(joint_state_timeout_sec=1.); p.expect(1., 'dynamic timeout')
    p.set_clock(9_000_000_000); p.expect(1., 'negative joint age remains fresh in baseline')


def test_reach_static_tf_dynamic_frame_links_thresholds_and_missing(make_pair):
    p = make_pair('horizontal_reach', {'scale_smoothing_alpha': 1., 'reach_update_period_sec': 0.})
    p.joint(); p.expect(.15, 'missing TF fail closed')
    p.transform(.65, static=True, stamp=0)
    p.joint(); p.expect(1-(.65-.42)/(.8865-.42)*.85, 'static zero stamp timeless')
    p.set(reach_folded_m=.5, reach_full_m=.8)
    p.joint(); p.expect(.575, 'dynamic reach thresholds')
    p.transform(.2, parent='base', child='offset', static=True, stamp=0)
    p.set(chassis_base_frame=p.frame('offset'))
    p.joint(); p.expect(1., 'dynamic base frame gives .45m')
    p.set(chassis_base_frame=p.frame('base'), monitored_links=[p.frame('offset')])
    p.joint(); p.expect(1., 'dynamic monitored link gives .2m')
    p.set(monitored_links=[p.frame('offset'), p.frame('missing')])
    p.joint(); p.expect(.15, 'any missing monitored TF fails closed')
    p.set(monitored_links=[]); p.joint(); p.expect(.15, 'empty monitored links fail closed')


def test_reach_tf_age_future_stale_cache_period_and_rollback(make_pair):
    p = make_pair('horizontal_reach', {'scale_smoothing_alpha': 1., 'reach_update_period_sec': .1})
    p.transform(.2, stamp=10_000_000_000)
    p.joint(); p.expect(1., 'fresh TF')
    p.transform(.9, stamp=10_000_000_000)
    # Same TF stamp may be ignored by tf2, so publish newer data and advance clock within cache.
    p.set_clock(10_050_000_000); p.transform(.9)
    p.joint(); p.expect(1., 'cached reach before period')
    p.set_clock(10_100_000_000); p.joint(); p.expect(.15, 'exact period boundary refresh')
    p.set(reach_update_period_sec=0.)
    p.transform(.2, stamp=10_100_000_000)
    p.set_clock(10_600_000_000); p.joint(); p.expect(1., 'TF age exactly timeout valid')
    p.set_clock(10_600_000_001); p.joint(); p.expect(.15, 'TF one nanosecond stale fails closed')
    p.set(reach_tf_timeout_sec=1.); p.joint(); p.expect(1., 'dynamic TF timeout')
    p.set_clock(9_900_000_000); p.joint(); p.expect(.15, 'future TF after clock rollback fails closed')


def test_reach_invalid_translation_and_recovery(make_pair):
    p = make_pair('horizontal_reach', {'scale_smoothing_alpha': 1., 'reach_update_period_sec': 0.})
    p.set(monitored_links=[p.frame('invalid')])
    p.transform(float('nan'), child='invalid')
    p.joint(); p.expect(.15, 'tf2 rejects NaN transform; absent chain protects')
    p.transform(.2, child='invalid', stamp=10_000_000_001)
    p.set_clock(10_000_000_001); p.joint(); p.expect(1., 'valid transform recovery')
    p.set(reach_full_m=.42)
    p.joint([1.2]); p.expect(1., 'invalid dynamic reach span holds previous state, baseline exception')
    p.set_clock(11_000_000_000); p.expect(.3, 'failed joint calculation does not refresh freshness')


def test_nonfinite_joints_and_cmd_components_preserve_baseline(make_pair):
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    for value in [float('nan'), float('inf'), -float('inf')]:
        p.joint([value]); p.expect(.15, 'nonfinite joint position saturates Python min/max activity')
    p.joint([0.], [float('nan')]); p.expect(.15, 'NaN velocity saturates activity')
    p.joint([0.]); p.expect(1., 'finite joint recovery')
    starts = {key:len(v) for key,v in p.values.items()}
    msg = p.Twist()
    msg.linear.x, msg.linear.y, msg.angular.z = float('nan'), float('inf'), -float('inf')
    p.cmd_pub.publish(msg)
    p.until(lambda: all(len(p.values[k]) > n for k,n in starts.items()))
    for key in starts:
        out = p.values[key][-1][1]
        assert math.isnan(out.linear.x) and out.linear.y == float('inf') and out.angular.z == -float('inf')
    p.steps.append({'case':'nonfinite Twist remains nonfinite, inherited input validation gap'})


def test_qos_and_tf_nonfinite_z(make_pair):
    from rclpy.qos import ReliabilityPolicy, DurabilityPolicy
    p = make_pair('horizontal_reach', {'scale_smoothing_alpha': 1., 'reach_update_period_sec': 0.})
    endpoints = p.node.get_subscriptions_info_by_topic('/' + p.prefix + '/input_remapped')
    assert len(endpoints) == 2
    for endpoint in endpoints:
        # Fast DDS endpoint discovery reports depth=0 (unknown), while each
        # constructor explicitly selects KeepLast(10). Check the exposed policies.
        assert endpoint.qos_profile.reliability == ReliabilityPolicy.RELIABLE
        assert endpoint.qos_profile.durability == DurabilityPolicy.VOLATILE
    p.transform(.2, z=float('inf'))
    p.joint(); p.expect(.15, 'invalid vertical translation protects despite planar metric')


def test_typed_atomic_updates_reject_without_partial_change(make_pair):
    from rclpy.parameter import Parameter
    from rcl_interfaces.srv import GetParameters
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    p.joint([1.2]); p.expect(.15, 'initial full scale')
    for name, value in [('reach_tf_timeout_sec', 1), ('min_speed_scale', True),
                        ('scale_smoothing_alpha', '0.5'), ('folded_reference_rad', [0, 0])]:
        changes = [Parameter('degraded_scale', value=.77).to_parameter_msg(),
                   Parameter(name, value=value).to_parameter_msg()]
        futures = {key:client.call_async(p.service.Request(parameters=changes)) for key,client in p.clients.items()}
        p.until(lambda:all(f.done() for f in futures.values()))
        assert all(not f.result().result.successful for f in futures.values())
        for key in p.clients:
            reader = p.node.create_client(GetParameters, '/' + p.prefix + '/' + key + '/arm_chassis_speed_coupling_node/get_parameters')
            p.until(reader.service_is_ready)
            future = reader.call_async(GetParameters.Request(names=['degraded_scale']))
            p.until(future.done)
            assert future.result().values[0].double_value == .3
            p.node.destroy_client(reader)
        p.steps.append({'invalid_typed_batch': {name:repr(value), 'degraded_scale':'.77'}, 'rejected_by_both':True})
        p.expect(.15, 'rejected atomic batch preserves scale')


def test_stale_warning_uses_wall_clock_during_ros_pause_and_rollback(make_pair):
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    p.joint([0.])
    p.set_clock(20_000_000_000)
    p.expect(.3, 'first stale warning')
    p.expect(.3, 'immediate duplicate throttled')
    p.pump(2.05)
    p.expect(.3, 'paused ROS clock, wall-time warning renews')
    p.pump(2.05)
    p.set_clock(19_000_000_000)
    p.expect(.3, 'backward ROS clock, wall-time warning renews')
    p.pump(.05)
    for key, needle in [('python', '/joint_states 已 '), ('cpp', 'Joint state stale (')]:
        text = (p.output / (key + '.log')).read_text()
        assert text.count(needle) == 3, (key, text)
    p.steps.append({'case':'wall-clock stale warning during simulated pause/rollback', 'expected_count_each':3})


@pytest.mark.parametrize('parameter,value', [('scale_smoothing_alpha', float('nan')),
                                           ('scale_smoothing_alpha', float('inf')),
                                           ('min_speed_scale', float('nan'))])
def test_nonfinite_scale_parameters_pollute_ema_until_restart(make_pair, parameter, value):
    p = make_pair(params={'scale_smoothing_alpha': 1.})
    p.joint([1.2]); p.expect(.15, 'finite initial state')
    p.set(**{parameter:value})
    p.joint([1.2]); p.expect(float('nan'), 'nonfinite parameter pollutes EMA, preserved baseline gap')
    p.set(scale_smoothing_alpha=1., min_speed_scale=.15)
    p.joint([0.]); p.expect(float('nan'), '0 times NaN retains polluted state, restart required in baseline')
    p.set_clock(11_000_000_000); p.expect(.3, 'freshness timeout still uses finite degraded_scale')


@pytest.mark.parametrize('timeout', [0., -.1, float('nan'), float('inf'), 1, True, '0.5'])
@pytest.mark.parametrize('implementation', ['python', 'cpp'])
def test_invalid_startup_timeout_fails(timeout, implementation, tmp_path):
    import yaml
    output = Path(os.environ.get('DYNAMICS_EVIDENCE', str(tmp_path))) / ('startup_' + implementation + '_' + str(timeout))
    output.mkdir(parents=True, exist_ok=True)
    config = output / 'parameters.yaml'
    config.write_text(yaml.safe_dump({'/**': {'ros__parameters': {'reach_tf_timeout_sec': timeout}}}))
    binary = Path(os.environ.get('DYNAMICS_CPP', '/missing/arm_chassis_speed_coupling_node'))
    assert implementation != 'cpp' or binary.is_file()
    command = ([sys.executable, str(HERE/'test_ros.py'), '--oracle'] if implementation == 'python' else [str(binary)]) + ['--ros-args', '--params-file', str(config)]
    env = dict(os.environ, ROS_DOMAIN_ID='140', ROS_LOCALHOST_ONLY='1', ROS_LOG_DIR=str(output/'ros_logs'))
    with (output/'child.log').open('w') as handle:
        child = subprocess.Popen(command, env=env, stdout=handle, stderr=subprocess.STDOUT)
        try:
            code = child.wait(timeout=5.)
            assert code != 0
        finally:
            if child.poll() is None:
                child.kill(); child.wait(timeout=2.)
    (output/'result.json').write_text(json.dumps({'implementation': implementation, 'pid': child.pid,
        'exit_code': child.returncode, 'owned_pid_reaped': child.poll() is not None, 'timeout_repr': repr(timeout)},indent=2)+'\n')


@pytest.mark.parametrize('params', [{'extension_metric': 'invalid'}, {'reach_folded_m': -.1}, {'reach_full_m': .42}])
def test_startup_metric_fallback(make_pair, params):
    p = make_pair('horizontal_reach', dict(params, scale_smoothing_alpha=1.))
    p.joint([0.]); p.expect(1., 'invalid startup metric/reach thresholds fall back to joint mode')
    p.joint([1.2]); p.expect(.15, 'fallback joint mode active')


if __name__ == '__main__' and '--oracle' in sys.argv:
    oracle_main()
