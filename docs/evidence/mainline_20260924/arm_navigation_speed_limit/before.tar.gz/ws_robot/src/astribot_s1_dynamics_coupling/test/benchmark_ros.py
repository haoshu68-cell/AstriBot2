#!/usr/bin/env python3
"""Alternating, isolated, paired CPU/RSS and correlated ROS round-trip latency.

Twist has no header. A sequence is encoded in vx/vy, whose ratio survives scale;
no timestamps are injected into the node and no outputs can reach a controller.
Latency includes publisher DDS, node, DDS back and driver scheduling, not just
callback compute. The sample CPU measure is /proc child utime+stime delta / wall.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import time

from test_ros import Pair


def quantile(values, fraction):
    values = sorted(values)
    index = (len(values) - 1) * fraction
    low = int(index)
    return values[low] + (values[min(low + 1, len(values)-1)] - values[low]) * (index-low)


def proc(pid):
    fields = Path('/proc', str(pid), 'stat').read_text().split(') ', 1)[1].split()
    ticks = int(fields[11]) + int(fields[12])
    rss = int(Path('/proc', str(pid), 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
    return ticks / os.sysconf('SC_CLK_TCK'), rss


def trial(index, implementation, duration, child_cpu, driver_cpu):
    import rclpy
    from geometry_msgs.msg import TransformStamped
    os.sched_setaffinity(0, {driver_cpu})
    rclpy.init()
    pair = None
    try:
        pair = Pair(f'benchmark_{index:02d}_{implementation}', 'horizontal_reach',
                    {'use_sim_time': False}, implementations=(implementation,))
        child = pair.processes[0][1]
        os.sched_setaffinity(child.pid, {child_cpu})
        # sched_setaffinity(pid) sets only the main thread; pin all existing DDS
        # threads too, and record the actual per-thread masks below.
        for task in Path('/proc', str(child.pid), 'task').iterdir():
            os.sched_setaffinity(int(task.name), {child_cpu})
        affinities = {task.name: sorted(os.sched_getaffinity(int(task.name)))
                      for task in Path('/proc', str(child.pid), 'task').iterdir()}
        expected_scale = 1 - (.65-.42)/(.8865-.42)*.85
        expected = {'cmd_hz':100, 'joint_hz':50, 'tf_hz':20, 'reach_m':.65, 'links':4,
                    'metric':'horizontal_reach', 'alpha':.25, 'scale':expected_scale}
        links = ['reach', 'reach2', 'reach3', 'reach4']
        pair.set(monitored_links=[pair.frame(link) for link in links])
        joint = pair.JointState()
        joint.name = [f'astribot_arm_{side}_joint_{i}' for side in ('left','right') for i in range(1,8)]
        joint.position, joint.velocity = [.4]*14, [.2]*14
        sent, received, samples, rss, gaps = {}, {}, [], [], []
        seq, consumed = 0, 0

        def feed_phase(seconds, record):
            nonlocal seq, consumed
            start = time.perf_counter()
            next_cmd = next_joint = next_tf = next_rss = start
            deadline = start + seconds
            counts = {'cmd':0, 'joint':0, 'tf_batches':0}
            while time.perf_counter() < deadline:
                now = time.perf_counter()
                assert child.poll() is None
                if now >= next_tf:
                    transforms = []
                    for i, link in enumerate(links):
                        message = TransformStamped()
                        message.header.frame_id, message.child_frame_id = pair.frame('base'), pair.frame(link)
                        message.header.stamp = pair.node.get_clock().now().to_msg()
                        message.transform.translation.x = .65 - i*.02
                        message.transform.rotation.w = 1.
                        transforms.append(message)
                    pair.tf.sendTransform(transforms)
                    next_tf += .05; counts['tf_batches'] += 1
                if now >= next_joint:
                    joint.header.stamp = pair.node.get_clock().now().to_msg()
                    pair.joint_pub.publish(joint)
                    next_joint += .02; counts['joint'] += 1
                if now >= next_cmd:
                    seq += 1
                    message = pair.Twist()
                    message.linear.x, message.linear.y, message.angular.z = .2 + seq*1e-6, .1, .07
                    stamp = time.perf_counter_ns()
                    if record: sent[seq] = stamp
                    pair.cmd_pub.publish(message)
                    next_cmd += .01; counts['cmd'] += 1
                if record and now >= next_rss:
                    rss.append(proc(child.pid)[1]); next_rss += .2
                rclpy.spin_once(pair.node, timeout_sec=.001)
                for receive_ns, message in pair.values[implementation][consumed:]:
                    key = round((message.linear.x/message.linear.y - 2.) / 1e-5)
                    if key in sent:
                        assert key not in received, 'duplicate output sequence'
                        received[key] = receive_ns
                        scale = message.linear.y/.1
                        assert abs(scale-expected_scale) < 1e-10, (scale, expected_scale)
                        assert abs(message.angular.z-.07*scale) < 1e-12
                        assert message.linear.z == message.angular.x == message.angular.y == 0.
                        samples.append([key, sent[key], receive_ns, (receive_ns-sent[key])/1e6, scale])
                consumed = len(pair.values[implementation])
            return counts

        feed_phase(2., False)
        start_cpu, start_rss = proc(child.pid)
        begin = time.perf_counter()
        counts = feed_phase(duration, True)
        elapsed = time.perf_counter() - begin
        end_cpu, end_rss = proc(child.pid)
        # Commands are sent at the beginning of each period; the final output is
        # normally consumed well before the end. Drain exceptional scheduling lag.
        pair.pump(.1)
        for receive_ns, message in pair.values[implementation][consumed:]:
            key = round((message.linear.x/message.linear.y - 2.) / 1e-5)
            if key in sent and key not in received:
                received[key] = receive_ns
                samples.append([key, sent[key], receive_ns, (receive_ns-sent[key])/1e6, message.linear.y/.1])
        latency = [row[3] for row in samples]
        result = {'trial': index, 'implementation': implementation, 'duration_s': elapsed,
                  'cpu_percent_one_core':100*(end_cpu-start_cpu)/elapsed,
                  'rss_mib_mean':statistics.mean(rss)/2**20, 'rss_mib_min':min(rss)/2**20,
                  'rss_mib_max':max(rss)/2**20, 'rss_mib_growth':(end_rss-start_rss)/2**20,
                  'latency_ms_p50':quantile(latency,.5), 'latency_ms_p95':quantile(latency,.95),
                  'latency_ms_p99':quantile(latency,.99), 'latency_ms_max':max(latency),
                  'input_counts':counts, 'paired_outputs':len(samples), 'missing_sequences':sorted(set(sent)-set(received)),
                  'workload':expected, 'driver_cpu':driver_cpu, 'child_cpu':child_cpu,
                  'child_thread_affinities':affinities}
        assert not result['missing_sequences'], result
        with (pair.output/'latency.csv').open('w') as handle:
            writer=csv.writer(handle); writer.writerow(['sequence','publish_monotonic_ns','receive_monotonic_ns','latency_ms','scale']); writer.writerows(samples)
        (pair.output/'measurement.json').write_text(json.dumps(result,indent=2)+'\n')
        return result
    finally:
        if pair is not None: pair.close()
        if rclpy.ok(): rclpy.shutdown()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--duration',type=float,default=10.)
    parser.add_argument('--pairs',type=int,default=4)
    args=parser.parse_args()
    allowed=sorted(os.sched_getaffinity(0))
    assert len(allowed)>=2
    driver_cpu,child_cpu=allowed[-1],allowed[-2]
    os.environ['ROS_DOMAIN_ID']=os.environ['DYNAMICS_DOMAIN']='141'
    os.environ['ROS_LOCALHOST_ONLY']='1'
    runs=[]
    for pair_index in range(args.pairs):
        for implementation in (('python','cpp') if pair_index%2==0 else ('cpp','python')):
            result=trial(len(runs),implementation,args.duration,child_cpu,driver_cpu)
            runs.append(result)
            print(json.dumps(result),flush=True)
    fields=['cpu_percent_one_core','rss_mib_mean','latency_ms_p50','latency_ms_p95','latency_ms_p99','latency_ms_max']
    summaries={}
    for implementation in ('python','cpp'):
        rows=[row for row in runs if row['implementation']==implementation]
        summaries[implementation]={field:{'median':statistics.median(row[field] for row in rows),
            'min':min(row[field] for row in rows),'max':max(row[field] for row in rows)} for field in fields}
    binary=Path(os.environ['DYNAMICS_CPP'])
    result={'scope':'isolated real ROS 2, no Gazebo, no hardware; endpoint round-trip latency',
            'platform':platform.platform(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'order':[row['implementation'] for row in runs], 'duration_s':args.duration,
            'cpu_affinity_original':allowed, 'summaries':summaries,'runs':runs,
            'paired_cpp_minus_python':[{field:next(r for r in runs[i:i+2] if r['implementation']=='cpp')[field]-
                next(r for r in runs[i:i+2] if r['implementation']=='python')[field] for field in fields}
                for i in range(0,len(runs),2)]}
    (Path(os.environ['DYNAMICS_EVIDENCE'])/'benchmark_summary.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__': main()
