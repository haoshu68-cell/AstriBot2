#include "astribot_s1_dynamics_coupling/core.hpp"

#include <geometry_msgs/msg/twist.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <tf2/exceptions.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#include <memory>
#include <utility>

namespace astribot_s1_dynamics_coupling {
class ArmChassisSpeedCouplingNode final : public rclcpp::Node {
 public:
  ArmChassisSpeedCouplingNode() : Node("arm_chassis_speed_coupling_node") {
    declare_parameter("input_topic", "/cmd_vel_pre_arm_coupling");
    declare_parameter("output_topic", "/cmd_vel");
    declare_parameter("joint_states_topic", "/joint_states");
    declare_parameter("extension_metric", "horizontal_reach");
    declare_parameter("chassis_base_frame", "astribot_torso_base");
    declare_parameter("reach_tf_timeout_sec", 0.5);
    const double timeout = number("reach_tf_timeout_sec");
    if (!std::isfinite(timeout) || timeout <= 0.0) {
      throw std::invalid_argument("reach_tf_timeout_sec must be finite and positive");
    }
    declare_parameter("monitored_links", std::vector<std::string>{
      "astribot_arm_left_tcp_link", "astribot_arm_right_tcp_link",
      "astribot_gripper_left_Link_L11", "astribot_gripper_right_Link_R11"});
    declare_parameter("reach_folded_m", 0.42);
    declare_parameter("reach_full_m", 0.8865);
    declare_parameter("reach_update_period_sec", 0.05);
    declare_parameter("folded_reference_rad", std::vector<double>(14, 0.0));
    declare_parameter("extension_full_rad", 1.2);
    declare_parameter("velocity_full_rad_s", 2.0);
    declare_parameter("min_speed_scale", 0.15);
    declare_parameter("scale_smoothing_alpha", 0.25);
    declare_parameter("joint_state_timeout_sec", 0.5);
    declare_parameter("degraded_scale", 0.3);
    declare_parameter("log_throttle_sec", 2.0);
    for (const auto * side : {"left", "right"}) {
      for (int i = 1; i <= 7; ++i) {
        joints_.push_back(std::string("astribot_arm_") + side + "_joint_" + std::to_string(i));
      }
    }
    publisher_ = create_publisher<geometry_msgs::msg::Twist>(string("output_topic"), 10);
    command_sub_ = create_subscription<geometry_msgs::msg::Twist>(string("input_topic"), 10,
      [this](geometry_msgs::msg::Twist::ConstSharedPtr msg) {command(*msg);});
    joint_sub_ = create_subscription<sensor_msgs::msg::JointState>(string("joint_states_topic"), 10,
      [this](sensor_msgs::msg::JointState::ConstSharedPtr msg) {joint(*msg);});
    metric_ = string("extension_metric");
    if (metric_ != "horizontal_reach" && metric_ != "joint_deviation") {
      RCLCPP_ERROR(get_logger(), "Invalid extension_metric; falling back to joint_deviation");
      metric_ = "joint_deviation";
    }
    if (metric_ == "horizontal_reach") {
      try {
        validate_reach_thresholds(number("reach_folded_m"), number("reach_full_m"));
      } catch (const std::invalid_argument & error) {
        RCLCPP_ERROR(get_logger(), "%s; falling back to joint_deviation", error.what());
        metric_ = "joint_deviation";
      }
    }
    if (metric_ == "horizontal_reach") {
      // Humble's frozen Python Buffer() has no ROS-clock jump callback. Use an
      // independent system clock so simulated-clock jumps do not erase its TF.
      tf_buffer_ = std::make_unique<tf2_ros::Buffer>(std::make_shared<rclcpp::Clock>(RCL_SYSTEM_TIME));
      tf_listener_ = std::make_unique<tf2_ros::TransformListener>(*tf_buffer_, this, false);
    } else {
      RCLCPP_WARN(get_logger(), "joint_deviation is the legacy diagnostic metric, not physical reach");
    }
    RCLCPP_INFO(get_logger(), "Arm/chassis coupling: %s -> %s, metric=%s, minimum=%.3f",
      string("input_topic").c_str(), string("output_topic").c_str(), metric_.c_str(), number("min_speed_scale"));
  }

 private:
  double number(const std::string & name) const {return get_parameter(name).as_double();}
  std::string string(const std::string & name) const {return get_parameter(name).as_string();}

  std::optional<double> max_horizontal_reach() {
    const auto base = string("chassis_base_frame");
    const auto links = get_parameter("monitored_links").as_string_array();
    std::optional<double> best;
    std::string best_link;
    bool failed = false;
    for (const auto & link : links) {
      try {
        const auto tf = tf_buffer_->lookupTransform(base, link, tf2::TimePointZero);
        const rclcpp::Time stamp(tf.header.stamp, get_clock()->get_clock_type());
        const auto & t = tf.transform.translation;
        const double age = (now() - stamp).seconds();
        if (!std::isfinite(t.x) || !std::isfinite(t.y) || !std::isfinite(t.z) ||
          (stamp.nanoseconds() != 0 && !(age >= 0.0 && age <= number("reach_tf_timeout_sec")))) {
          failed = true;
          continue;
        }
        const double reach = horizontal_reach(t.x, t.y);
        if (!best || reach > *best) {best = reach; best_link = link;}
      } catch (const tf2::TransformException &) {failed = true;}
    }
    if (!best || failed) {
      if (!tf_warned_) RCLCPP_WARN(get_logger(), "Monitored TF missing, stale, future or invalid; full reach activity");
      tf_warned_ = true;
      last_reach_link_.clear();
      return std::nullopt;
    }
    tf_warned_ = false;
    last_reach_link_ = best_link;
    return best;
  }

  double extension_activity(const JointMap & positions) {
    if (metric_ == "joint_deviation") {
      return joint_deviation_activity(positions, joints_,
        get_parameter("folded_reference_rad").as_double_array(), number("extension_full_rad"));
    }
    const auto stamp = now();
    const auto age = last_reach_time_ ? (stamp - *last_reach_time_).nanoseconds() : -1;
    if (!last_reach_time_ || !(age >= 0 && age < number("reach_update_period_sec") * 1e9)) {
      last_reach_ = max_horizontal_reach();
      last_reach_time_ = stamp;
    }
    if (!last_reach_) return 1.0;
    return reach_activity(*last_reach_, number("reach_folded_m"), number("reach_full_m"));
  }

  void joint(const sensor_msgs::msg::JointState & msg) {
    try {
      const auto positions = zip_map(msg.name, msg.position);
      const auto velocities = msg.velocity.size() == msg.name.size() ? zip_map(msg.name, msg.velocity) : JointMap{};
      const double extension = extension_activity(positions);
      const double velocity = velocity_activity(velocities, joints_, number("velocity_full_rad_s"));
      const double activity = std::max(extension, velocity);
      const double raw = scale_from_activity(activity, number("min_speed_scale"));
      const double alpha = number("scale_smoothing_alpha");
      current_scale_ = alpha * raw + (1.0 - alpha) * current_scale_;
      last_joint_time_ = now();
      const auto stamp = now();
      if (!last_log_time_ || !((stamp - *last_log_time_).nanoseconds() < number("log_throttle_sec") * 1e9)) {
        last_log_time_ = stamp;
        if (activity > 0.05) {
          RCLCPP_INFO(get_logger(), "Arm activity=%.2f (extension=%.2f, velocity=%.2f), scale=%.2f",
            activity, extension, velocity, current_scale_);
        }
      }
    } catch (const std::exception & error) {
      RCLCPP_ERROR(get_logger(), "Joint calculation failed; retaining previous scale: %s", error.what());
    }
  }

  double effective_scale() {
    if (!last_joint_time_) return number("degraded_scale");
    const double age = (now() - *last_joint_time_).seconds();
    if (age > number("joint_state_timeout_sec")) {
      RCLCPP_WARN_THROTTLE(get_logger(), warning_clock_, 2000, "Joint state stale (%.3fs), using degraded scale", age);
      return number("degraded_scale");
    }
    return current_scale_;
  }

  void command(const geometry_msgs::msg::Twist & msg) {
    double scale = 1.0;
    try {scale = effective_scale();}
    catch (const std::exception & error) {
      RCLCPP_ERROR(get_logger(), "Scale calculation failed; forwarding unrestricted: %s", error.what());
    }
    try {
      geometry_msgs::msg::Twist out;
      out.linear.x = msg.linear.x * scale;
      out.linear.y = msg.linear.y * scale;
      out.angular.z = msg.angular.z * scale;
      publisher_->publish(out);
    } catch (const std::exception & error) {
      RCLCPP_ERROR(get_logger(), "Scaled publish failed; forwarding original: %s", error.what());
      publisher_->publish(msg);
    }
  }

  std::vector<std::string> joints_;
  std::string metric_, last_reach_link_;
  double current_scale_{1.0};
  bool tf_warned_{false};
  std::optional<rclcpp::Time> last_joint_time_, last_reach_time_, last_log_time_;
  std::optional<double> last_reach_;
  // rclpy's per-call logger throttle defaults to SYSTEM_TIME, independently of
  // the ROS clock used by freshness, reach caching and activity-log throttling.
  rclcpp::Clock warning_clock_{RCL_SYSTEM_TIME};
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::unique_ptr<tf2_ros::TransformListener> tf_listener_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr command_sub_;
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_sub_;
};
}  // namespace astribot_s1_dynamics_coupling

int main(int argc, char ** argv) {
  rclcpp::init(argc, argv);
  try {
    rclcpp::spin(std::make_shared<astribot_s1_dynamics_coupling::ArmChassisSpeedCouplingNode>());
  } catch (const std::exception & error) {
    RCLCPP_FATAL(rclcpp::get_logger("arm_chassis_speed_coupling_node"), "%s", error.what());
    rclcpp::shutdown();
    return 1;
  }
  rclcpp::shutdown();
  return 0;
}
